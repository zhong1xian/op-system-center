package com.only4play.system.infrastructure.facade;

/**
 * 流水号生成门面
 */
public interface IFlowNoFacade {

  Long getNextId();

}
