package com.only4play.system.domain.invoice.orderreceipt.domainservice.model;

import com.only4play.common.annotation.FieldDesc;
import lombok.Data;

@Data
public class CustomerModel {

  @FieldDesc(name = "名称")
  private String name;

  @FieldDesc(name = "纳税人识别号")
  private String taxNo;

  @FieldDesc(name = "地址")
  private String address;

  @FieldDesc(name = "电话")
  private String phone;

  @FieldDesc(name = "银行及")
  private String bank;

  @FieldDesc(name = "账号")
  private String account;

  private String email;

}
