import request from '@/utils/request'

export function create(params) {
  return request({
    url: '/template/objectTemplate/v1/createObjectTemplate',
    method: 'post',
    data: params
  })
}

export function addTemplateItem(params) {
  return request({
    url: '/template/objectTemplate/v1/addTemplateItem',
    method: 'post',
    data: params
  })
}

export function update(params) {
  return request({
    url: '/template/objectTemplate/v1/updateObjectTemplate',
    method: 'post',
    data: params
  })
}

export function findByPage(params) {
  return request({
    url: '/template/objectTemplate/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function valid(id) {
  return request({
    url: '/template/objectTemplate/v1/valid/' + id,
    method: 'post'
  })
}

export function invalid(id) {
  return request({
    url: '/template/objectTemplate/v1/invalid/' + id,
    method: 'post'
  })
}

export function getTemplateByCategoryCode(code) {
  return request({
    url: '/template/objectTemplate/v1/getTemplateByCategoryCode/' + code,
    method: 'get'
  })
}

export function getTemplateItemsById(id) {
  return request({
    url: '/template/objectTemplate/v1/getTemplateItemsById/' + id,
    method: 'get'
  })
}
