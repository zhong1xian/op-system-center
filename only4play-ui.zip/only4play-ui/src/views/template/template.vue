<template>
  <div class="app-container">
    <div class="block">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-input v-model="listQuery.name" size="mini" placeholder="分类名称" />
        </el-col>
        <el-col :span="6">
          <el-button type="success" size="mini" icon="el-icon-search" @click.native="search">查找</el-button>
          <el-button type="success" size="mini" icon="el-icon-plus" @click.native="handleAdd">添加
          </el-button>
        </el-col>
      </el-row>
      <br>
    </div>
    <el-table
      :data="list"
      style="width: 100%"
    >
      <el-table-column label="模板名称">
        <template v-slot="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column label="模板编码">
        <template v-slot="scope">
          {{ scope.row.code }}
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.validStatus == 'INVALID'"
            size="mini"
            type="success"
            @click="handleValid(scope.row.id)"
          >启用
          </el-button>
          <el-button
            v-if="scope.row.validStatus == 'VALID'"
            size="mini"
            type="danger"
            @click="handleInValid(scope.row.id)"
          >禁用
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleUpdate(scope.row)"
          >修改
          </el-button>
          <el-button
            size="mini"
            type="primary"
            @click="configItem(scope.row)"
          >配置模板项
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="margin-top:15px"
      align="right"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :page-size="listQuery.limit"
      :total="total"
      @current-change="fetchPage"
      @prev-click="fetchPrev"
      @next-click="fetchNext"
    />

    <el-dialog :visible.sync="itemFormVisible" title="关联模板项">
      <el-form ref="itemForm" :model="itemFormData" :rules="itemRules" size="medium" label-width="100px">
        <el-form-item label="关联模板项" prop="itemIds">
          <el-select v-model="itemFormData.templateItemIds" multiple placeholder="请选择关联的模版项" clearable :style="{width: '100%'}">
            <el-option
              v-for="(item, index) in itemIdsOptions"
              :key="index"
              :label="item.name"
              :value="item.id"
              :disabled="item.disabled"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="itemFormVisible = false">取消</el-button>
        <el-button type="primary" @click="addTemplateItem">确定</el-button>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="addFormVisible" title="添加模板">
      <el-form ref="elForm" :model="formData" :rules="rules" size="medium" label-width="100px">
        <el-form-item label="模板名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入模板名称" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="模板编码" prop="code">
          <el-input v-model="formData.code" placeholder="请输入模板编码" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="模板分类" prop="categoryId">
          <el-select v-model="formData.categoryId" placeholder="请选择模板分类" clearable :style="{width: '100%'}">
            <el-option
              v-for="(item, index) in categoryIdOptions"
              :key="index"
              :label="item.name"
              :value="item.id"
              :disabled="item.disabled"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="formData.description" placeholder="请输入描述" clearable :style="{width: '100%'}" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="close">取消</el-button>
        <el-button type="primary" @click="handelConfirm">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  findByPage,
  valid,
  invalid,
  create,
  addTemplateItem
} from '@/api/template/template'
import { findAllValidCategory } from '@/api/template/templateCategory'
import { findTemplateItemByCondition } from '@/api/template/templateItem'
export default {
  components: {},
  inheritAttrs: false,
  props: [],
  data() {
    return {
      addFormVisible: false,
      itemFormVisible: false,
      listQuery: {
        page: 1,
        limit: 10,
        name: ''
      },
      total: 0,
      list: null,
      listLoading: true,
      formData: {
        name: undefined,
        code: undefined,
        categoryId: undefined,
        description: undefined
      },
      itemFormData: {
        templateId: '',
        templateItemIds: undefined
      },
      itemRules: {
        templateItemIds: [{
          required: true,
          message: '请选择关联的模版项',
          trigger: 'change'
        }]
      },
      itemIdsOptions: [],
      rules: {
        name: [{
          required: true,
          message: '请输入模板名称',
          trigger: 'blur'
        }],
        code: [{
          required: true,
          message: '请输入模板编码',
          trigger: 'blur'
        }],
        categoryId: [{
          required: true,
          message: '请选择模板分类',
          trigger: 'change'
        }],
        description: [{
          required: true,
          message: '请输入描述',
          trigger: 'blur'
        }]
      },
      categoryIdOptions: []
    }
  },
  created() {
    this.init()
    findAllValidCategory().then(response => {
      this.categoryIdOptions = response.result
    })
  },
  methods: {
    init() {
      this.fetchData()
    },
    fetchData() {
      this.listLoading = true
      const queryData = {
        'bean': {
          'name': this.listQuery.name
        },
        'pageSize': this.listQuery.limit,
        'page': this.listQuery.page
      }
      findByPage(queryData).then(response => {
        this.list = response.result.list
        this.listLoading = false
        this.total = response.result.total
      })
    },
    search() {
      this.fetchData()
    },
    reset() {
      this.listQuery.name = ''
      this.fetchData()
    },
    handleFilter() {
      this.listQuery.page = 1
      this.fetchData()
    },
    handleValid(id) {
      valid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '启用成功'
        })
        this.fetchData()
      })
    },
    handleInValid(id) {
      invalid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '禁用成功'
        })
        this.fetchData()
      })
    },
    fetchNext() {
      this.listQuery.page = this.listQuery.page + 1
      this.fetchData()
    },
    fetchPrev() {
      this.listQuery.page = this.listQuery.page - 1
      this.fetchData()
    },
    fetchPage(page) {
      this.listQuery.page = page
      this.fetchData()
    },
    changeSize(limit) {
      this.listQuery.limit = limit
      this.fetchData()
    },
    handleUpdate() {

    },
    handleAdd() {
      this.addFormVisible = true
    },
    close() {
      this.addFormVisible = false
    },
    handelConfirm() {
      this.$refs['elForm'].validate(valid => {
        if (!valid) return
        create(JSON.stringify(this.formData)).then(response => {
          this.$message.success({
            type: 'success',
            message: '保存成功'
          })
          this.fetchData()
        })
        this.close()
      })
    },
    addTemplateItem() {
      this.$refs['itemForm'].validate(valid => {
        if (!valid) return
        addTemplateItem(JSON.stringify(this.itemFormData)).then(response => {
          this.$message.success({
            type: 'success',
            message: '保存成功'
          })
          this.fetchData()
        })
        this.itemFormVisible = false
      })
    },
    configItem(row) {
      this.itemFormData.templateId = row.id
      this.itemFormVisible = true
      const queryData = {
        'name': '',
        'code': ''
      }
      findTemplateItemByCondition(queryData).then(response => {
        this.itemIdsOptions = response.result
      })
    }
  }
}
</script>
