import request from '@/utils/request'

export function findByPage(params) {
  return request({
    url: '/asset/asset/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function assetIn(params) {
  return request({
    url: '/asset/asset/v1/assetIn',
    method: 'post',
    data: params
  })
}

export function assetTransfer(params) {
  return request({
    url: '/asset/asset/v1/assetTransfer',
    method: 'post',
    data: params
  })
}
