<template>
  <div class="app-container">
    <div class="block">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-input v-model="listQuery.name" size="mini" placeholder="平台名称" />
        </el-col>
        <el-col :span="6">
          <el-button type="success" size="mini" icon="el-icon-search" @click.native="search">查找</el-button>
          <el-button type="success" size="mini" icon="el-icon-plus" @click.native="handleAdd">添加
          </el-button>
        </el-col>
      </el-row>
      <br>
    </div>
    <el-table
      :data="list"
      style="width: 100%"
    >
      <el-table-column label="SKU名称">
        <template v-slot="scope">
          {{ scope.row.skuName }}
        </template>
      </el-table-column>
      <el-table-column label="SKU编码">
        <template v-slot="scope">
          {{ scope.row.code }}
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.validStatus == '0'"
            size="mini"
            type="success"
            @click="handleValid(scope.row.id)"
          >启用
          </el-button>
          <el-button
            v-if="scope.row.validStatus == '1'"
            size="mini"
            type="danger"
            @click="handleInValid(scope.row.id)"
          >禁用
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleUpdate(scope.row)"
          >修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="margin-top:15px"
      align="right"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :page-size="listQuery.limit"
      :total="total"
      @current-change="fetchPage"
      @prev-click="fetchPrev"
      @next-click="fetchNext"
    />
  </div>
</template>

<script>
import {
  findByPage,
  valid,
  invalid
} from '@/api/asset/objectSku'

export default {
  components: {},
  inheritAttrs: false,
  props: [],
  data() {
    return {
      listQuery: {
        page: 1,
        limit: 10,
        name: ''
      },
      total: 0,
      list: null,
      listLoading: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.fetchData()
    },
    fetchData() {
      this.listLoading = true
      const queryData = {
        'bean': {
          'name': this.listQuery.name
        },
        'pageSize': this.listQuery.limit,
        'page': this.listQuery.page
      }
      findByPage(queryData).then(response => {
        this.list = response.result.list
        this.listLoading = false
        this.total = response.result.total
      })
    },
    search() {
      this.fetchData()
    },
    reset() {
      this.listQuery.name = ''
      this.fetchData()
    },
    handleFilter() {
      this.listQuery.page = 1
      this.fetchData()
    },
    handleValid(id) {
      valid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '启用成功'
        })
        this.fetchData()
      })
    },
    handleInValid(id) {
      invalid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '禁用成功'
        })
        this.fetchData()
      })
    },
    fetchNext() {
      this.listQuery.page = this.listQuery.page + 1
      this.fetchData()
    },
    fetchPrev() {
      this.listQuery.page = this.listQuery.page - 1
      this.fetchData()
    },
    fetchPage(page) {
      this.listQuery.page = page
      this.fetchData()
    },
    changeSize(limit) {
      this.listQuery.limit = limit
      this.fetchData()
    },
    handleUpdate() {

    },
    handleAdd() {

    }
  }
}
</script>
