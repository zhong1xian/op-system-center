package com.only4play.system.domain.invoice.orderreceipt.events;

import com.only4play.system.domain.invoice.orderreceipt.OrderReceipt;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterResultModel;
import java.util.List;
import lombok.Value;

public interface OrderReceiptEvents {

  @Value
  class OrderRegisterEvent {

    private OrderReceipt orderReceipt;
    private OrderRegisterModel orderRegisterModel;
    private OrderRegisterResultModel registerResultModel;
  }

  @Value
  class ReceiptExchangeInvoiceEvent {

    private OrderReceipt orderReceipt;
    private List<Long> receiptIds;
    private String batchNo;
  }

}
