package com.only4play.codegen.processor.updater;

public @interface IgnoreUpdater {

}
