package com.only4play.common.annotation;

/**
 * @Author: Gim
 * @Date: 2019/11/25 16:20
 * @Description:
 */
public @interface FieldDesc {
    String name() default "";
}
