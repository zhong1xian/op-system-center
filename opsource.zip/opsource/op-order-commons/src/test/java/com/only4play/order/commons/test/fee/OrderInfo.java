package com.only4play.order.commons.test.fee;

import lombok.Data;

/**
 * @author gim 2021/12/6 8:26 下午
 */
@Data
public class OrderInfo {

  private String tradeFlowNo;
  private String orderType;

}
