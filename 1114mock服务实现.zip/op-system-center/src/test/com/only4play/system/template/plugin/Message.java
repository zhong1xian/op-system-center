package com.only4play.system.template.plugin;

import lombok.Data;

@Data
public class Message {
    private String messageChannel;
}
