const apiUrl = process.env.VUE_APP_BASE_API
const uploadUrl = process.env.VUE_APP_UPLOAD_URL
export function getApiUrl() {
  return apiUrl
}

export function getUploadUrl() {
  return uploadUrl
}

const opMap = new Map()
opMap.set('IN_PURCHASE', '采购入库')
opMap.set('OUT_SALE_TO_AGENT', '销售给代理商')
opMap.set('OUT_SALE_TO_USER', '销售给用户')
opMap.set('OUT_FOR_RETURN', '退货出库')
opMap.set('IN_FOR_RETURN', '退货入库')
opMap.set('OUT_TRANSFER', '转仓出库')
opMap.set('IN_TRANSFER', '转仓入库')
const inOutMap = new Map()
inOutMap.set('In', '入库')
inOutMap.set('OUT', '出库')

const storeTypeMap = new Map()
storeTypeMap.set('SYSTEM', '公司仓库')
storeTypeMap.set('AGENT', '代理商仓库')
storeTypeMap.set('USER', '用户仓库')

const tradeMap = new Map()
tradeMap.set('RECHARGE', '充值')
tradeMap.set('PAY', '扣款')

const orderStatusMap = new Map()
orderStatusMap.set('ORDER_WAIT_PAY', '待支付')
orderStatusMap.set('ORDER_WAIT_OUT_STORE', '支付成功待出库')
orderStatusMap.set('ORDER_PART_OUT', '部分出库')
orderStatusMap.set('ORDER_ALL_OUT', '全部出库')
orderStatusMap.set('ORDER_CANCEL', '订单取消')
orderStatusMap.set('ORDER_COMPLETE', '已完成')
orderStatusMap.set('ORDER_REJECT', '被驳回')

const orderTypeMap = new Map()
orderTypeMap.set('AGENT', '代理商订单')
orderTypeMap.set('USER', '用户订单')

const orderChannelMap = new Map()
orderChannelMap.set('IPAD', 'name')
orderChannelMap.set('SYSTEM', '后台系统')
orderChannelMap.set('AGENT_ORDER', '代理上下单')

const questionTypeMap = new Map()
questionTypeMap.set('SINGLE_SELECT', '单选')
questionTypeMap.set('MULTI_SELECT', '多选')
questionTypeMap.set('VARIABLE_SELECT', '不定项')

const questionLevelMap = new Map()
questionLevelMap.set('EASY', '简单')
questionLevelMap.set('MEDIUM', '中等')
questionLevelMap.set('HARD', '难')

const itemsMap = new Map()
itemsMap.set(1, {
  itemFlag: 'A',
  rightFlag: false,
  sortNum: 1
})
itemsMap.set(2, {
  itemFlag: 'B',
  rightFlag: false,
  sortNum: 2
})
itemsMap.set(3, {
  itemFlag: 'C',
  rightFlag: false,
  sortNum: 3
})
itemsMap.set(4, {
  itemFlag: 'D',
  rightFlag: false,
  sortNum: 4
})
itemsMap.set(5, {
  itemFlag: 'E',
  rightFlag: false,
  sortNum: 5
})
itemsMap.set(6, {
  itemFlag: 'F',
  rightFlag: false,
  sortNum: 6
})
itemsMap.set(7, {
  itemFlag: 'G',
  rightFlag: false,
  sortNum: 7
})
itemsMap.set(8, {
  itemFlag: 'H',
  rightFlag: false,
  sortNum: 8
})

export function formatQuestionType(key) {
  return questionTypeMap.get(key)
}

export function getItemValue(key) {
  return itemsMap.get(key)
}

export function duplicateRemove(arr, type) {
  const newArr = []
  const tArr = []
  if (arr.length === 0) {
    return arr
  } else {
    if (type) {
      for (let i = 0; i < arr.length; i++) {
        if (!tArr[arr[i][type]]) {
          newArr.push(arr[i])
          tArr[arr[i][type]] = true
        }
      }
      return newArr
    } else {
      for (let i = 0; i < arr.length; i++) {
        if (!tArr[arr[i]]) {
          newArr.push(arr[i])
          tArr[arr[i]] = true
        }
      }
      return newArr
    }
  }
}

export function formatQuestionLevel(key) {
  return questionLevelMap.get(key)
}

export function formatStoreType(key) {
  return storeTypeMap.get(key)
}

export function formatInOut(key) {
  return inOutMap.get(key)
}

export function formatOperate(key) {
  return opMap.get(key)
}

export function formatTradeType(key) {
  return tradeMap.get(key)
}

export function formatOrderStatus(key) {
  return orderStatusMap.get(key)
}

export function formatOrderChannel(key) {
  return orderChannelMap.get(key)
}

export function formatOrderType(key) {
  return orderTypeMap.get(key)
}
