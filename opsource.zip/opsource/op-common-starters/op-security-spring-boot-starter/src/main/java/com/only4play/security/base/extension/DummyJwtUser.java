package com.only4play.security.base.extension;

import com.only4play.security.base.BaseJwtUser;

public class DummyJwtUser extends BaseJwtUser {

}
