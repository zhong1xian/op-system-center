package com.only4play.ui.config;

/**
 * 这个项目是能写class的，这是只是展示一下而已
 */
public class CodeGenUIAutoConfigure {

}
