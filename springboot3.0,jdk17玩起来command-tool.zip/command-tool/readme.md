springboot3.0
jdk17 起步

sdkMan jdk 管理工具

jdk 17 怎么玩
jenv 快速切换

怎么jdk 切换

jenv enable-plugin maven


mvn -Pnative native:compile

在mac下awt 问题并未解决
https://github.com/oracle/graal/issues/4124

spring shell 版本 必须要3.0以后

用处 mock服务 给测试用。不用装jdk了!

https://spring.io/blog/2022/09/26/native-support-in-spring-boot-3-0-0-m5
