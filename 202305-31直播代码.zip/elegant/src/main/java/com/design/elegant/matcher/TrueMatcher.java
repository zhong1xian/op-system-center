package com.design.elegant.matcher;

public class TrueMatcher {

}
