import request from '@/utils/request'

export function saveRole(params) {
  return request({
    url: '/perm/role/v1/createRole',
    method: 'post',
    data: params
  })
}

export function updateRole(params) {
  return request({
    url: '/perm/role/v1/updateRole',
    method: 'post',
    data: params
  })
}

export function validRole(id) {
  return request({
    url: '/perm/role/v1/valid/' + id,
    method: 'post'
  })
}

export function invalidRole(id) {
  return request({
    url: '/perm/role/v1/invalid/' + id,
    method: 'post'
  })
}

export function findRolesByPage(params) {
  return request({
    url: '/perm/role/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function findValidRoles(params) {
  return request({
    url: '/perm/role/v1/findAllValidRoles',
    method: 'post',
    data: params
  })
}

export function getUsersByRoleCode(params) {
  return request({
    url: '/perm/role/v1/getAllUsersByRoleCode',
    method: 'post',
    data: params
  })
}

export function getUserByRoleId(params) {
  return request({
    url: '/perm/role/v1/getAllUsersByRoleId',
    method: 'post',
    data: params
  })
}

export function getUserByRoleName(params) {
  return request({
    url: '/perm/role/v1/getAllUsersByRoleName',
    method: 'post',
    data: params
  })
}

export function grantRoleResources(params) {
  return request({
    url: '/perm/role/v1/grantRoleResources',
    method: 'post',
    data: params
  })
}

export function getResourceTreeByRoleId(roleId) {
  return request({
    url: '/perm/role/v1/getResourceTreeById',
    method: 'post',
    params: { roleId: roleId }
  })
}

export function getRoleResourceIds(roleId) {
  return request({
    url: '/perm/role/v1/getRoleResourceIds/' + roleId,
    method: 'post'
  })
}

export function getAllValidRoles() {
  return request({
    url: '/perm/role/v1/findAllValidRoles',
    method: 'post'
  })
}
