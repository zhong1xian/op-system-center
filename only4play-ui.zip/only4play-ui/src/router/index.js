import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: '管理中心首页',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '管理中心', icon: 'dashboard' }
    }]
  },
  {
    path: '/permission',
    component: Layout,
    redirect: '/permission/list',
    name: '权限管理',
    meta: {
      title: '权限管理',
      icon: 'form'
    },
    children: [
      {
        path: 'list',
        name: '资源列表',
        component: () => import('@/views/resource/resourceList'),
        meta: { title: '资源列表', icon: 'form' }
      },
      {
        path: 'add',
        name: '资源添加',
        component: () => import('@/views/resource/resourceAdd'),
        meta: { title: '资源添加', icon: 'form' }
      },
      {
        path: 'update',
        name: '资源修改',
        component: () => import('@/views/resource/resourceUpdate'),
        meta: { title: '资源修改', icon: 'form' },
        hidden: true
      },
      {
        path: 'roleList',
        name: '角色管理',
        component: () => import('@/views/role/roleList'),
        meta: { title: '角色管理', icon: 'form' }
      },
      {
        path: 'platformList',
        name: '平台管理',
        component: () => import('@/views/platform/platformList'),
        meta: { title: '平台管理', icon: 'form' }
      },
      {
        path: 'userList',
        name: '后台用户列表',
        component: () => import('@/views/user/userList'),
        meta: { title: '后台用户列表', icon: 'form' }
      }
    ]
  },
  {
    path: '/template',
    component: Layout,
    redirect: '/template/template',
    name: '模板管理',
    meta: {
      title: '模板管理',
      icon: 'form'
    },
    children: [
      {
        path: 'templateCategory',
        name: '模板类别',
        component: () => import('@/views/template/templateCategory'),
        meta: { title: '模板类别', icon: 'form' }
      },
      {
        path: 'template',
        name: '模板管理',
        component: () => import('@/views/template/template'),
        meta: { title: '模板管理', icon: 'form' }
      },
      {
        path: 'templateItem',
        name: '模板项管理',
        component: () => import('@/views/template/templateItem'),
        meta: { title: '模板项管理', icon: 'form' }
      },
      {
        path: 'mockRule',
        name: '规则管理',
        component: () => import('@/views/template/mockRule'),
        meta: { title: '规则管理', icon: 'form' }
      },
      {
        path: 'selectDict',
        name: '下拉字典管理',
        component: () => import('@/views/template/selectDict'),
        meta: { title: '下拉字典管理', icon: 'form' }
      }
    ]
  },
  {
    path: '/objectSku',
    component: Layout,
    redirect: '/objectSku/objectSku',
    name: 'SKU管理',
    meta: {
      title: '资产管理',
      icon: 'form'
    },
    children: [
      {
        path: 'objectSku',
        name: 'SKU列表',
        component: () => import('@/views/asset/objectSku'),
        meta: { title: 'SKU列表', icon: 'form' }
      },
      {
        path: 'skuAdd',
        name: 'SKU添加',
        component: () => import('@/views/asset/skuAdd'),
        meta: { title: 'SKU添加', icon: 'form' }
      },
      {
        path: 'assetIn',
        name: '资产入库',
        component: () => import('@/views/asset/assetIn'),
        meta: { title: '资产入库', icon: 'form' }
      },
      {
        path: 'assetTransfer',
        name: '资产调拨',
        component: () => import('@/views/asset/assetTransfer'),
        meta: { title: '资产调拨', icon: 'form' }
      },
      {
        path: 'assetLifecycle',
        name: '资产生命周期',
        component: () => import('@/views/asset/assetLifecycle'),
        meta: { title: '资产生命周期', icon: 'form' }
      },
      {
        path: 'assetInOutRecord',
        name: '资产出入记录',
        component: () => import('@/views/asset/assetInOutRecord'),
        meta: { title: '资产出入记录', icon: 'form' }
      }
    ]
  },
  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
