import request from '@/utils/request'

export function savePlatform(params) {
  return request({
    url: '/perm/platform/v1/createPlatform',
    method: 'post',
    data: params
  })
}

export function updatePlatform(params) {
  return request({
    url: '/perm/platform/v1/updatePlatform',
    method: 'post',
    data: params
  })
}

export function findPlatformByPage(params) {
  return request({
    url: '/perm/platform/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function findValidPlatforms(params) {
  return request({
    url: '/perm/platform/v1/findAll',
    method: 'post',
    data: params
  })
}

export function validPlatform(id) {
  return request({
    url: '/perm/platform/v1/valid/' + id,
    method: 'post'
  })
}

export function invalidPlatform(id) {
  return request({
    url: '/perm/platform/v1/invalid/' + id,
    method: 'post'
  })
}

