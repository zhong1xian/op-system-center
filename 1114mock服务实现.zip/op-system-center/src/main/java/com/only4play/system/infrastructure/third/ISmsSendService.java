package com.only4play.system.infrastructure.third;

public interface ISmsSendService {

  boolean sendSms(SmsSendModel sendModel);

}
