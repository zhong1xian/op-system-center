package com.only4play.codegen.test;

public interface Constants {

  String GEN_API_SOURCE = "/Users/gim/MyProject/op-codegen-plugin/op-codegen-test/src/main/java";

}
