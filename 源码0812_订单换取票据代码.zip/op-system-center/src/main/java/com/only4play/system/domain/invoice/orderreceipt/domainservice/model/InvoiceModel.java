package com.only4play.system.domain.invoice.orderreceipt.domainservice.model;

import com.only4play.common.annotation.FieldDesc;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class InvoiceModel {

  @FieldDesc(name = "开票金额")
  private BigDecimal amount;

  @FieldDesc(name = "申请流水号")
  private Long registerFlowNo;

  @FieldDesc(name = "申请订单Id")
  private Long recordId;

  @FieldDesc(name = "纳税人识别号")
  private String taxNo;

  @FieldDesc(name = "开票主体名称")
  private String name;

  @FieldDesc(name = "组织机构代码")
  private String organizationCode;

  @FieldDesc(name = "交易类型编码")
  private String tradeTypeCode;

  private String accountId;

  @FieldDesc(name = "银行及账号")
  private String bankAccount;

  @FieldDesc(name = "地址及电话")
  private String addressPhone;


  private String ouCode;


}
