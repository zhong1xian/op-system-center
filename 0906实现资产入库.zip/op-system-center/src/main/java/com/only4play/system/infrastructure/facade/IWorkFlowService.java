package com.only4play.system.infrastructure.facade;

public interface IWorkFlowService {

}
