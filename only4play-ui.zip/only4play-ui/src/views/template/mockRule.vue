<template>
  <div class="app-container">
    <div class="block">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-input v-model="listQuery.name" size="mini" placeholder="平台名称" />
        </el-col>
        <el-col :span="6">
          <el-button type="success" size="mini" icon="el-icon-search" @click.native="search">查找</el-button>
          <el-button type="success" size="mini" icon="el-icon-plus" @click.native="handleAdd">添加
          </el-button>
        </el-col>
      </el-row>
      <br>
    </div>
    <el-table
      :data="list"
      style="width: 100%"
    >
      <el-table-column label="平台名称">
        <template v-slot="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column label="平台编码">
        <template v-slot="scope">
          {{ scope.row.code }}
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.validStatus == 'INVALID'"
            size="mini"
            type="success"
            @click="handleValid(scope.row.id)"
          >启用
          </el-button>
          <el-button
            v-if="scope.row.validStatus == 'VALID'"
            size="mini"
            type="danger"
            @click="handleInValid(scope.row.id)"
          >禁用
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleUpdate(scope.row)"
          >修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="margin-top:15px"
      align="right"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :page-size="listQuery.limit"
      :total="total"
      @current-change="fetchPage"
      @prev-click="fetchPrev"
      @next-click="fetchNext"
    />

    <el-dialog :visible.sync="addFormVisible" title="添加规则">
      <el-form ref="ruleForm" :model="ruleData" :rules="mockRules" size="medium" label-width="100px">
        <el-form-item label="规则名称" prop="name">
          <el-input v-model="ruleData.name" placeholder="请输入规则名称" clearable :style="{width: '100%'}" />
        </el-form-item>
<!--        <el-form-item label="规则编码" prop="code">-->
<!--          <el-input v-model="ruleData.code" placeholder="请输入规则编码" clearable :style="{width: '100%'}" />-->
<!--        </el-form-item>-->
        <el-form-item label="排序号" prop="sortNum">
          <el-input-number v-model="ruleData.sortNum" placeholder="排序号" :step="1" />
        </el-form-item>
        <el-form-item label="描述信息" prop="descInfo">
          <el-input v-model="ruleData.descInfo" placeholder="请输入描述信息" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="规则配置" prop="ruleList">
          <el-select v-model="ruleData.ruleList" placeholder="请下拉选择选择规则配置" clearable :style="{width: '100%'}" @change="changeSelect">
            <el-option
              v-for="(item, index) in ruleListOptions"
              :key="index"
              :label="item.name"
              :value="item"
            />
          </el-select>
          <div v-for="(kv,i) in ruleData.kvList" :key="i" style="margin-top: 10px;">
            <el-row :gutter="18">
              <el-col :span="6">
                {{ kv.l }}
                <el-input v-model="kv.k" placeholder="键" type="hidden" />
              </el-col>
              <el-col :span="6" v-if="kv.inputType == null">
                <el-input v-model="kv.v" placeholder="值" />
              </el-col>
              <el-col :span="6" v-if="kv.inputType == '5'">
                <el-select v-model="kv.v" placeholder="请下拉选择" :style="{width: '100%'}">
                  <el-option
                    v-for="(item, index) in extMap[kv.k]"
                    :key="index"
                    :label="item.l"
                    :value="item.k"
                    :disabled="item.disabled"
                  />
                </el-select>
              </el-col>
              <el-col :span="6" v-if="kv.inputType == '3'">
                <el-date-picker
                  v-model="kv.v"
                  type="date"
                  value-format="yyyy-MM-DD"
                  placeholder="选择日期">
                </el-date-picker>
<!--                <el-input v-model="kv.v" placeholder="日期" />-->
              </el-col>
            </el-row>
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="addFormVisible=false">取消</el-button>
        <el-button type="primary" @click="handelConfirm">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  findByPage,
  valid,
  invalid,
  getRuleConfigList,
  create
} from '@/api/template/mockRule'

export default {
  components: {},
  inheritAttrs: false,
  props: [],
  data() {
    return {
      listQuery: {
        page: 1,
        limit: 10,
        name: ''
      },
      total: 0,
      list: null,
      listLoading: true,
      ruleData: {
        name: undefined,
        code: undefined,
        sortNum: undefined,
        descInfo: undefined,
        kvList: [],
        ruleList: null
      },
      selectValues: [],
      extMap: {},
      addFormVisible: false,
      mockRules: {
        name: [{
          required: true,
          message: '请输入规则名称',
          trigger: 'blur'
        }],
        code: [{
          required: true,
          message: '请输入规则编码',
          trigger: 'blur'
        }],
        sortNum: [{
          required: true,
          message: '排序号',
          trigger: 'blur'
        }],
        descInfo: [{
          required: true,
          message: '请输入描述信息',
          trigger: 'blur'
        }],
        ruleList: []
      },
      ruleListOptions: []
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      getRuleConfigList().then(response => {
        this.ruleListOptions = response.result
      })
      this.fetchData()
    },
    fetchData() {
      this.listLoading = true
      const queryData = {
        'bean': {
          'name': this.listQuery.name
        },
        'pageSize': this.listQuery.limit,
        'page': this.listQuery.page
      }
      findByPage(queryData).then(response => {
        this.list = response.result.list
        this.listLoading = false
        this.total = response.result.total
      })
    },
    search() {
      this.fetchData()
    },
    reset() {
      this.listQuery.name = ''
      this.fetchData()
    },
    handleFilter() {
      this.listQuery.page = 1
      this.fetchData()
    },
    handleValid(id) {
      valid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '启用成功'
        })
        this.fetchData()
      })
    },
    handleInValid(id) {
      invalid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '禁用成功'
        })
        this.fetchData()
      })
    },
    fetchNext() {
      this.listQuery.page = this.listQuery.page + 1
      this.fetchData()
    },
    fetchPrev() {
      this.listQuery.page = this.listQuery.page - 1
      this.fetchData()
    },
    fetchPage(page) {
      this.listQuery.page = page
      this.fetchData()
    },
    changeSize(limit) {
      this.listQuery.limit = limit
      this.fetchData()
    },
    handleUpdate() {

    },
    handleAdd() {
      this.addFormVisible = true
    },
    changeSelect(item) {
      this.extMap = item.ext
      this.ruleData.ruleList = item.name
      this.ruleData.code = item.code
      const obj = item.params
      this.ruleData.kvList = []
      for (let i = 0; i < obj.length; i++) {
        this.ruleData.kvList.push({ 'v': '', 'k': obj[i].k, 'l': obj[i].v, 'inputType': obj[i].l })
      }
    },
    close() {
      this.$emit('update:visible', false)
    },
    handelConfirm() {
      this.$refs['ruleForm'].validate(valid => {
        if (!valid) return
        create(this.ruleData).then(response => {
          this.$message.success({
            type: 'success',
            message: '保存成功'
          })
          this.addFormVisible = false
          this.fetchData()
        })
      })
    }
  }
}
</script>

