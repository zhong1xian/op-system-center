package com.only4play.system.domain.invoice.orderreceipt.domainservice.model;

import com.only4play.common.annotation.FieldDesc;
import lombok.Data;

/**
 * 根据实际业务进行查询开票
 */
@Data
public class ExchangeConditionModel {

  private String tradeType;

  private String phone;

  private InvoiceStyle invoiceStyle;

  private InvoiceType invoiceType;

  @FieldDesc(name = "是否为预览")
  private boolean preview;

  /**
   * 购方信息
   */
  private CustomerModel customerModel;

}
