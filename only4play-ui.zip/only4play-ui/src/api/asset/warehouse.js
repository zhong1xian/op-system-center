import request from '@/utils/request'

export function create(params) {
  return request({
    url: '/asset/warehouse/v1/createWarehouse',
    method: 'post',
    data: params
  })
}

export function update(params) {
  return request({
    url: '/asset/warehouse/v1/updateWarehouse',
    method: 'post',
    data: params
  })
}

export function findByPage(params) {
  return request({
    url: '/asset/warehouse/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function valid(id) {
  return request({
    url: '/asset/warehouse/v1/valid/' + id,
    method: 'post'
  })
}

export function invalid(id) {
  return request({
    url: '/asset/warehouse/v1/invalid/' + id,
    method: 'post'
  })
}

export function getAllWarehouse() {
  return request({
    url: '/asset/warehouse/v1/getAllWarehouse',
    method: 'post'
  })
}
