package com.only4play.system.domain.trade.order.domainservice.model;

/**
 * 订单修订模型
 */
public class OrderReviseModel {

}
