<template>
  <div class="app-container">
    <div class="block">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-input v-model="listQuery.name" size="mini" placeholder="平台名称" />
        </el-col>
        <el-col :span="6">
          <el-button type="success" size="mini" icon="el-icon-search" @click.native="search">查找</el-button>
          <el-button type="success" size="mini" icon="el-icon-plus" @click.native="handleAdd">添加
          </el-button>
        </el-col>
      </el-row>
      <br>
    </div>
    <el-table
      :data="list"
      style="width: 100%"
    >
      <el-table-column label="字典名称">
        <template v-slot="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column label="字典编码">
        <template v-slot="scope">
          {{ scope.row.code }}
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.validStatus == 'INVALID'"
            size="mini"
            type="success"
            @click="handleValid(scope.row.id)"
          >启用
          </el-button>
          <el-button
            v-if="scope.row.validStatus == 'VALID'"
            size="mini"
            type="danger"
            @click="handleInValid(scope.row.id)"
          >禁用
          </el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleUpdate(scope.row)"
          >修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="margin-top:15px"
      align="right"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :page-size="listQuery.limit"
      :total="total"
      @current-change="fetchPage"
      @prev-click="fetchPrev"
      @next-click="fetchNext"
    />

    <el-dialog :visible.sync="addFormVisible" title="添加字典信息">
      <el-form ref="elForm" :model="addFormData" :rules="rules" size="medium" label-width="100px">
        <el-form-item label="名称" prop="name">
          <el-input v-model="addFormData.name" placeholder="请输入名称" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="字典编码" prop="code">
          <el-input v-model="addFormData.code" placeholder="请输入字典编码" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="字典类型" prop="dictType">
          <el-select v-model="addFormData.dictType" placeholder="请选择字典类型" clearable :style="{width: '100%'}">
            <el-option
              v-for="(item, index) in dictTypeOptions"
              :key="index"
              :label="item.label"
              :value="item.value"
              :disabled="item.disabled"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="接口地址" prop="httpUrl">
          <el-input v-model="addFormData.httpUrl" placeholder="请输入接口地址" clearable :style="{width: '100%'}" />
        </el-form-item>
        <el-form-item label="值列表">
          <el-button @click="addKeyValue" >添加键值对</el-button> <el-button @click="removeKeyValue" >移除键值对</el-button>
          <div v-for="(kv,i) in addFormData.selectValues" :key="i" style="margin-top: 5px;">
            <el-row :gutter="18">
              <el-col :span="6">
                <el-input v-model="kv.k" placeholder="键" />
              </el-col>
              <el-col :span="6">
                <el-input v-model="kv.v" placeholder="值" />
              </el-col>
              <el-col :span="6">
                <el-input v-model="kv.l" placeholder="标签" />
              </el-col>
            </el-row>
          </div>
        </el-form-item>
        <el-form-item label="备注" prop="description">
          <el-input v-model="addFormData.description" placeholder="请输入备注" clearable :style="{width: '100%'}" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="close">取消</el-button>
        <el-button type="primary" @click="handelConfirm">确定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import {
  findByPage,
  valid,
  invalid,
  create
} from '@/api/template/selectDict'

export default {
  components: {},
  inheritAttrs: false,
  props: [],
  data() {
    return {
      listQuery: {
        page: 1,
        limit: 10,
        name: ''
      },
      total: 0,
      list: null,
      listLoading: true,
      addFormVisible: false,
      updateFormVisible: false,
      addFormData: {
        name: undefined,
        code: undefined,
        dictType: 2,
        httpUrl: undefined,
        description: undefined,
        selectValues: []
      },
      rules: {
        name: [{
          required: true,
          message: '请输入名称',
          trigger: 'blur'
        }],
        code: [{
          required: true,
          message: '请输入字典编码',
          trigger: 'blur'
        }],
        dictType: [{
          required: true,
          message: '请选择字典类型',
          trigger: 'change'
        }],
        httpUrl: [{
          required: true,
          message: '请输入接口地址',
          trigger: 'blur'
        }],
        field105: [{
          required: true,
          message: '请输入单行文本',
          trigger: 'blur'
        }]
      },
      dictTypeOptions: [{
        'label': '下拉列表',
        'value': 1
      }, {
        'label': 'http调用',
        'value': 2
      }]
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.fetchData()
    },
    fetchData() {
      this.listLoading = true
      const queryData = {
        'bean': {
          'name': this.listQuery.name
        },
        'pageSize': this.listQuery.limit,
        'page': this.listQuery.page
      }
      findByPage(queryData).then(response => {
        this.list = response.result.list
        this.listLoading = false
        this.total = response.result.total
      })
    },
    search() {
      this.fetchData()
    },
    reset() {
      this.listQuery.name = ''
      this.fetchData()
    },
    handleFilter() {
      this.listQuery.page = 1
      this.fetchData()
    },
    handleValid(id) {
      valid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '启用成功'
        })
        this.fetchData()
      })
    },
    handleInValid(id) {
      invalid(id).then(response => {
        this.$message.success({
          type: 'success',
          message: '禁用成功'
        })
        this.fetchData()
      })
    },
    fetchNext() {
      this.listQuery.page = this.listQuery.page + 1
      this.fetchData()
    },
    fetchPrev() {
      this.listQuery.page = this.listQuery.page - 1
      this.fetchData()
    },
    fetchPage(page) {
      this.listQuery.page = page
      this.fetchData()
    },
    changeSize(limit) {
      this.listQuery.limit = limit
      this.fetchData()
    },
    handleUpdate() {

    },
    handleAdd() {
      this.addFormVisible = true
    },
    handelConfirm() {
      this.$refs['elForm'].validate(valid => {
        if (!valid) return
        create(JSON.stringify(this.addFormData)).then(response => {
          this.$message.success({
            type: 'success',
            message: '保存成功'
          })
          this.addFormData.selectValues = []
          this.fetchData()
        })
        this.close()
      })
    },
    close() {
      this.addFormVisible = false
    },
    addKeyValue() {
      this.addFormData.selectValues.push({ 'k': '', 'v': '', 'l': '' })
    },
    removeKeyValue() {
      this.addFormData.selectValues.pop()
    }
  }
}
</script>
