package com.only4play.system.domain.invoice.orderreceipt.domainservice;

import com.only4play.jpa.support.EntityOperations;
import com.only4play.order.commons.constants.BizEnum;
import com.only4play.order.commons.filters.selector.FilterSelector;
import com.only4play.order.commons.filters.selector.LocalListBasedFilterSelector;
import com.only4play.system.domain.invoice.orderreceipt.OrderReceipt;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.ExchangeConditionModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.ExchangeInvoiceModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.InvoiceModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterResultModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.FilterChainPipeline;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.context.ExchangeInvoiceContext;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.context.OrderReceiptContext;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.exchange.SaveExchangeLogFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.exchange.SplitAmountFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.exchange.TradeRouterFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.register.CalculateValidAmountFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.register.EnterpriseRouterFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.register.PopulateReceiptItemFilter;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.pipeline.filters.register.SaveRegisterLogFilter;
import com.only4play.system.domain.invoice.orderreceipt.mapper.OrderReceiptMapper;
import com.only4play.system.domain.invoice.orderreceipt.repository.OrderReceiptRepository;
import com.only4play.system.infrastructure.facade.IFlowNoFacade;
import io.vavr.Tuple2;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderReceiptDomainServiceImpl implements IOrderReceiptDomainService {

  private final FilterChainPipeline orderRegisterPipeline;

  private final FilterChainPipeline exchangeInvoicePipeline;

  private final OrderReceiptRepository orderReceiptRepository;

  private final IFlowNoFacade flowNoFacade;


  @Override
  public OrderRegisterResultModel orderRegister(OrderRegisterModel registerModel) {
    //选择要执行的filter
    FilterSelector selector = getOrderRegisterSelector();
    //构建上下文
    OrderReceiptContext orderReceiptContext = new OrderReceiptContext(BizEnum.BIZ_XXX, selector);
    //请求模型设置到上下文
    orderReceiptContext.setModel(registerModel);
    //设置一个结果bean
    OrderRegisterResultModel resultModel = new OrderRegisterResultModel();
    orderReceiptContext.setRegisterResultModel(resultModel);
    orderRegisterPipeline.getFilterChain().handle(orderReceiptContext);
    //调用凭据对象的注册方法、
    OrderReceipt orderReceipt = OrderReceiptMapper.INSTANCE.registerModel2Entity(registerModel);
    orderReceipt.setRegisterFlowNo(flowNoFacade.getNextId());
    EntityOperations
        .doCreate(orderReceiptRepository)
        .create(() -> orderReceipt)
        .update(r -> r.orderRegister(registerModel,orderReceiptContext.getRegisterResultModel()))
        .execute();
    return orderReceiptContext.getRegisterResultModel();
  }

  @Override
  public boolean receiptAbandon(List<Long> ids) {
    return false;
  }

  @Override
  public List<Tuple2<String, Map<Integer, List<InvoiceModel>>>> exchangeInvoice(
      ExchangeInvoiceModel exchangeInvoiceModel) {
    FilterSelector selector = getExchangeSelector();
    ExchangeInvoiceContext invoiceContext = new ExchangeInvoiceContext(BizEnum.BIZ_XXX, selector);
    invoiceContext.setExchangeInvoiceModel(exchangeInvoiceModel);
    exchangeInvoicePipeline.getFilterChain().handle(invoiceContext);
    return invoiceContext.getInvoiceList();
  }

  @Override
  public List<Tuple2<String, Map<Integer, List<InvoiceModel>>>> exchangeInvoiceByCondition(
      ExchangeConditionModel conditionModel) {
    return null;
  }

  @Override
  public void completeInvoice(List<Long> ids) {

  }


  private FilterSelector getOrderRegisterSelector() {
    LocalListBasedFilterSelector selector = new LocalListBasedFilterSelector();
    selector.addFilter(CalculateValidAmountFilter.class.getSimpleName());
    selector.addFilter(SaveRegisterLogFilter.class.getSimpleName());
    selector.addFilter(PopulateReceiptItemFilter.class.getSimpleName());
    selector.addFilter(EnterpriseRouterFilter.class.getSimpleName());
    return selector;
  }

  private FilterSelector getExchangeSelector() {
    LocalListBasedFilterSelector selector = new LocalListBasedFilterSelector();
    selector.addFilter(SaveExchangeLogFilter.class.getSimpleName());
    selector.addFilter(SplitAmountFilter.class.getSimpleName());
    selector.addFilter(TradeRouterFilter.class.getSimpleName());
    return selector;
  }
}
