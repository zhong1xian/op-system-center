package com.only4play.system.infrastructure.constants;


public interface MessageConstants {

  String PHONE = "phone";
  String ROBOT = "robot";
  String ACCOUNT = "account";
  String VERIFY_CODE = "verifyCode";

}
