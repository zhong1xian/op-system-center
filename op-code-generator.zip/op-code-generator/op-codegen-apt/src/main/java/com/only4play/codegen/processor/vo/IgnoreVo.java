package com.only4play.codegen.processor.vo;

/**
 * @Author: Gim
 * @Description:
 */
public @interface IgnoreVo {

}
