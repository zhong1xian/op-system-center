package com.only4play.system.domain.invoice.orderreceipt.domainservice;

import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.ExchangeConditionModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.ExchangeInvoiceModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.InvoiceModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterModel;
import com.only4play.system.domain.invoice.orderreceipt.domainservice.model.OrderRegisterResultModel;
import io.vavr.Tuple2;
import java.util.List;
import java.util.Map;

/**
 * 凭据领域服务层
 */
public interface IOrderReceiptDomainService {

  /**
   * 注册凭据
   */
  OrderRegisterResultModel orderRegister(OrderRegisterModel registerModel);

  /**
   * 凭据作废
   */
  boolean receiptAbandon(List<Long> ids);

  /**
   * 开票==换取发票
   */
  List<Tuple2<String, Map<Integer, List<InvoiceModel>>>> exchangeInvoice(ExchangeInvoiceModel exchangeInvoiceModel);

  /**
   * 根据条件开票
   */
  List<Tuple2<String, Map<Integer, List<InvoiceModel>>>> exchangeInvoiceByCondition(ExchangeConditionModel conditionModel);

  /**
   * 开票完成
   */
  void completeInvoice(List<Long> ids);

}
