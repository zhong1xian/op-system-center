package com.only4play.test;

import org.junit.jupiter.api.Test;

public class GenericTest {


  @Test
  public void testDir(){
    System.out.println(System.getProperty("user.dir"));
  }

}
