package com.only4play.exam.domain.task.domainservice;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class TaskDomainServiceImpl implements ITaskDomainService{

  @Override
  public void start(Long taskId) {

  }

  @Override
  public void end(Long taskId) {

  }
}
