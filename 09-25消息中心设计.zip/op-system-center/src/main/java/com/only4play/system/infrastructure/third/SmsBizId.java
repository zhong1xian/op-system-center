package com.only4play.system.infrastructure.third;


public interface SmsBizId {

  String  ALI_SMS_BIZ = "ali";

}
