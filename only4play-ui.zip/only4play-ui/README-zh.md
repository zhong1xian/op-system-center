# 统一管理系统
npm install

### 修改后台服务地址
在vue.config.js中修改 target 为后端服务地址

```js
proxy: {
      // change xxx-api/login => mock/login
      // detail: https://cli.vuejs.org/config/#devserver-proxy
      [process.env.VUE_APP_BASE_API]: {
        target: `http://127.0.0.1:9301`,
        changeOrigin: true,
        pathRewrite: {
          ['^' + process.env.VUE_APP_BASE_API]: ''
        }
      }
    }
```

### 运行server 并且启动
* npm run dev

### 运行
* npm run build:prod

### nginx 部署
将构建的dist copy 到服务器上，添加 server

```js
server {
        listen 8888; #开放的端口
        server_name auth.xxx.com;#需要配置的域名，测试环境可有可无
        root /XXXXX/dist;#dist文件目录
        location / {
           # root   html;
            try_files $uri $uri/ @router;
             index  index.html index.htm;
         }
        location @router{
                rewrite ^.*$/ index.html last;
        }
        location ~ ^/api/ {
                rewrite ^/api/(.*)$ /$1 break;
                proxy_pass http://localhost:9400;#部署的 authority 服务地址
        }
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }
     }
```

nvm 安装
brew update
brew install nvm

mkdir ~/.nvm

vim ~/.bash_profile


export NVM_DIR=~/.nvm
source $(brew --prefix nvm)/nvm.sh


source ~/.bash_profile

M1 pro的话需要将 node版本调整为 V 14.7.0
https://tecadmin.net/install-nvm-macos-with-homebrew/
如果是Mac 电脑需要安装 python2

Python 2 安装

https://www.python.org/downloads/release/python-2718/

依赖安装完成之后
执行 yarn install
运行执行 npm run dev

表单生成器
https://mrhj.gitee.io/form-generator/#/