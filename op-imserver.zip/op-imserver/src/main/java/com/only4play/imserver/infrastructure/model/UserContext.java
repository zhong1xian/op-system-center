package com.only4play.imserver.infrastructure.model;

import lombok.Data;

@Data
public class UserContext {

  private Long userId;

  private String username;

}
