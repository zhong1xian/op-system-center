package com.only4play.imserver;

import cn.hutool.extra.spring.EnableSpringUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author gim
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableSpringUtil
@EnableAsync
public class OpIMServerApplication {

  public static void main(String[] args) {
    SpringApplication.run(OpIMServerApplication.class, args);
  }

}
