package com.only4play.system.template.matcher;

import lombok.Data;

@Data
public class UserContext {

  private String name;

  private Integer age;

}
