import request from '@/utils/request'

export function saveRoleGroup(params) {
  return request({
    url: '/admin/roleGroup/createRoleGroup',
    method: 'post',
    data: params
  })
}

export function updateRoleGroup(params) {
  return request({
    url: '/admin/roleGroup/updateRoleGroup',
    method: 'post',
    data: params
  })
}

export function validRoleGroup(id) {
  return request({
    url: '/admin/roleGroup/validRoleGroup/' + id,
    method: 'post'
  })
}

export function invalidRoleGroup(id) {
  return request({
    url: '/admin/roleGroup/invalidRoleGroup/' + id,
    method: 'post'
  })
}

export function findRoleGroupByPage(params) {
  return request({
    url: '/admin/roleGroup/findAllRoleGroupsByPage',
    method: 'post',
    data: params
  })
}

export function findValidRoleGroups(params) {
  return request({
    url: '/admin/roleGroup/findAllValidRoleGroups',
    method: 'post',
    data: params
  })
}
