TODO

校验

权限

限流

防重复

审计


asset 资产中心 /asset/
perm 权限中心 /perm/
template 模板中心 /template/
invoice 发票中心 /invoice/


在单体应用里就是不同的模块
在不同的服务里就是微服务
