package com.only4play.system.infrastructure.constants;

/**
 * @author noon
 * @date 2022/8/30
 */
public interface AuthConstants {

  Long ROOT_RESOURCE_ID = 0L;

  String ID = "id";

  String LOGIN_USER_TYPE = "login_type";
}
