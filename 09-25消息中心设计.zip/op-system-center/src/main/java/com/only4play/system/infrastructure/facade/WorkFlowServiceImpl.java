package com.only4play.system.infrastructure.facade;

import org.springframework.stereotype.Service;

@Service
public class WorkFlowServiceImpl implements IWorkFlowService{

}
