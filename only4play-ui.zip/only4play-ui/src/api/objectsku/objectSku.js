import request from '@/utils/request'

export function findAllUsersByPage(params) {
  return request({
    url: '/auth/adminUser/findByPage',
    method: 'post',
    data: params
  })
}
export function modifyPass(params) {
  return request({
    url: '/order/adminUser/modifyPass',
    method: 'post',
    data: params
  })
}

export function validUser(id) {
  return request({
    url: '/admin/adminUser/valid/' + id,
    method: 'post'
  })
}

export function invalidUser(id) {
  return request({
    url: '/admin/adminUser/invalid/' + id,
    method: 'post'
  })
}

export function findCurrentUserAllRoles(params) {
  return request({
    url: '/admin/adminUser/getCurrentUserAllRolesByUserId',
    method: 'post',
    data: params
  })
}

export function create(params) {
  return request({
    url: '/admin/adminUser/create',
    method: 'post',
    data: params
  })
}

export function findUserPlatforms(params) {
  return request({
    url: '/admin/adminUser/getCurrentUserPlatforms',
    method: 'post',
    data: params
  })
}

export function findMenuTree(params) {
  return request({
    url: '/admin/adminUser/getCurrentUserResourceMenuTree',
    method: 'post',
    data: params
  })
}

export function grantUserRoles(params) {
  return request({
    url: '/admin/adminUser/grantUserRoles',
    method: 'post',
    data: params
  })
}

export function findUserAllRoles(id) {
  return request({
    url: '/admin/adminUser/getUserAllRolesByUserId/' + id,
    method: 'post'
  })
}

export function findUserPlatformsById(id) {
  return request({
    url: '/admin/adminUser/getUserPlatforms/' + id,
    method: 'post'
  })
}

export function getUserRoles(id) {
  return request({
    url: '/admin/adminUser/getUserRoles/' + id,
    method: 'post'
  })
}

export function getUserPlatforms(id) {
  return request({
    url: '/admin/adminUser/getUserPlatforms/' + id,
    method: 'post'
  })
}

export function grantUserPlatforms(params) {
  return request({
    url: '/admin/adminUser/grantUserPlatforms',
    method: 'post',
    data: params
  })
}

