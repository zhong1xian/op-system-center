package com.only4play.system.domain.invoice.orderreceipt.domainservice.model;

import com.only4play.common.annotation.FieldDesc;
import java.util.List;
import lombok.Data;

/**
 * 开票
 */
@Data
public class ExchangeInvoiceModel {

  private InvoiceStyle invoiceStyle;

  private InvoiceType invoiceType;

  /**
   * 购方信息
   */
  private CustomerModel customerModel;

  @FieldDesc(name = "是否为预览")
  private boolean preview;

  @FieldDesc(name = "凭据Id 列表")
  private List<Long> ids;

}
