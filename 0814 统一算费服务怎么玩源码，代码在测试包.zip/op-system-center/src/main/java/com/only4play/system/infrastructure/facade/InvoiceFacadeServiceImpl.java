package com.only4play.system.infrastructure.facade;

import com.only4play.common.constants.ValidStatus;
import com.only4play.common.exception.BusinessException;
import com.only4play.system.domain.invoice.enterpriseentity.service.IEnterpriseEntityService;
import com.only4play.system.domain.invoice.enterpriseentity.vo.EnterpriseEntityVO;
import com.only4play.system.domain.invoice.enterpriserouter.EnterpriseRouter;
import com.only4play.system.domain.invoice.enterpriserouter.repository.EnterpriseRouterRepository;
import com.only4play.system.domain.invoice.payitemconfig.PayItemConfig;
import com.only4play.system.domain.invoice.payitemconfig.repository.PayItemConfigRepository;
import com.only4play.system.domain.invoice.payitemconfig.vo.PayItemConfigVO;
import com.only4play.system.domain.invoice.taxrateconfig.TaxRateConfig;
import com.only4play.system.domain.invoice.taxrateconfig.repository.TaxRateConfigRepository;
import com.only4play.system.domain.invoice.taxrateconfig.vo.TaxRateConfigVO;
import com.only4play.system.infrastructure.constants.InvoiceErrorCode;
import com.only4play.system.infrastructure.model.CodeValue;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class InvoiceFacadeServiceImpl implements IInvoiceFacadeService {

  private final EnterpriseRouterRepository enterpriseRouterRepository;

  private final IEnterpriseEntityService enterpriseEntityService;

  private final PayItemConfigRepository payItemConfigRepository;

  private final TaxRateConfigRepository taxRateConfigRepository;

  /**
   * 一般公司也不会有太多的企业开票主体,太多就加缓存
   *
   * @param orderAttr
   * @return
   */
  @Override
  public EnterpriseEntityVO orderRouter2TaxCode(List<CodeValue> orderAttr) {
    //根据排序匹配到最优路由
    List<RouterCheckerModel> models = orderAttr.stream()
        .map(v -> new RouterCheckerModel(v.getK(), v.getV())).collect(Collectors.toList());
    Optional<EnterpriseRouter> enterpriseRouter = enterpriseRouterRepository.findAll()
        .stream()
        .filter(r -> Objects.equals(ValidStatus.VALID, r.getValidStatus()))
        .sorted(Comparator.comparingInt(EnterpriseRouter::getSortNum))
        .filter(router -> models.containsAll(
            router.getCodeValueList()
                .stream()
                .map(v -> new RouterCheckerModel(v.getK(), v.getV()))
                .collect(Collectors.toList())))
        .findFirst();
    if (enterpriseRouter.isPresent()) {
      EnterpriseEntityVO vo = enterpriseEntityService.findById(
          enterpriseRouter.get().getEnterpriseId());
      return vo;
    } else {
      throw new BusinessException(InvoiceErrorCode.ENTERPRISE_NOT_FIND);
    }
  }

  @Override
  public List<PayItemConfigVO> getPayItemConfigs(String tradeTypeCode) {
    List<PayItemConfig> configs = payItemConfigRepository.findPayItemConfigsByTradeTypeCode(
        tradeTypeCode);
    return configs.stream().map(entity -> new PayItemConfigVO(entity)).collect(Collectors.toList());
  }


  @Override
  public Optional<TaxRateConfigVO> findRateConfigByTaxCategoryCode(String taxCategoryCode) {
    Optional<TaxRateConfig> taxRate = taxRateConfigRepository.findByTaxCategoryCode(
        taxCategoryCode);
    if(taxRate.isPresent()){
      return Optional.of(new TaxRateConfigVO(taxRate.get()));
    }
    return Optional.empty();
  }

  @Value
  class RouterCheckerModel {

    private String code;
    private String value;
  }

}
