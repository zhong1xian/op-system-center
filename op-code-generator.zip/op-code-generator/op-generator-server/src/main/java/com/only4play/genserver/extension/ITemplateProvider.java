package com.only4play.genserver.extension;

public interface ITemplateProvider {

  String getTemplateStr();

}
