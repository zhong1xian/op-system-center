package com.only4play.opmybatisdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.only4play.opmybatisdemo.entity.customer.Customer;

public interface CustomerMapper extends BaseMapper<Customer> {

}
