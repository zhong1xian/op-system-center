import request from '@/utils/request'

export function findByPage(params) {
  return request({
    url: '/asset/assetLifecycle/v1/findByPage',
    method: 'post',
    data: params
  })
}

