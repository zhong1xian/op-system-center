import request from '@/utils/request'

export function saveResource(params) {
  return request({
    url: '/perm/resource/v1/createResource',
    method: 'post',
    data: params
  })
}

export function updateResource(params) {
  return request({
    url: '/perm/resource/v1/updateResource',
    method: 'post',
    data: params
  })
}

export function enableResource(id) {
  return request({
    url: '/perm/resource/v1/valid/' + id,
    method: 'post'
  })
}

export function disableResource(id) {
  return request({
    url: '/perm/resource/v1/invalid/' + id,
    method: 'post'
  })
}

export function findByPage(params) {
  return request({
    url: '/perm/resource/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function getResourceTree(platformId) {
  return request({
    url: '/perm/resource/v1/getResourceTreeByPlatform/' + platformId,
    method: 'post'
  })
}
