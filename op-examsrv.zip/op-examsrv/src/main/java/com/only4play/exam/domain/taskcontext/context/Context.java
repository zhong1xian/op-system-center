package com.only4play.exam.domain.taskcontext.context;

import com.only4play.exam.domain.taskcontext.ContextType;

public interface Context {

  ContextType getContextType();

}
