package com.only4play.opmybatisdemo.entity.customer;

import lombok.Data;

@Data
public class CustomerUpdater {

  private Long id;
  private String username;

}
