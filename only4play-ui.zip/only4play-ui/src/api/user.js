import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/auth/admin/pass',
    method: 'post',
    data: {
      'username': data.username,
      'password': data.password
    }
  })
}

/**
 * 手机验证码登录
 * @param data
 * @returns
 */
export function phoneLogin(data) {
  return request({
    url: '/auth/admin/sms',
    method: 'post',
    data: {
      'phone': data.phone,
      'verifyCode': data.verifyCode
    }
  })
}

export function getInfo(token) {
  return request({
    url: '/admin/sysUser/getUserInfoByToken',
    method: 'post',
    params: { 'token': token },
    baseURL: 'http://10.32.64.20:9400'
  })
}

export function sendVerityCode(phone) {
  return request({
    url: '/admin/auth/getVerifyCode',
    method: 'post',
    data: { 'phone': phone }
  })
}

export function logout() {
  return request({
    url: '/user/logout',
    method: 'post'
  })
}
