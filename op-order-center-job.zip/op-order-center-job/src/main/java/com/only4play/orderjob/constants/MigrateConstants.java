package com.only4play.orderjob.constants;

/**
 * @author mac
 */
public interface MigrateConstants {

  String END_ID = "endId";
  String START_ID = "startId";

  String SHARDING_ITEM = "shardingItem";
}
