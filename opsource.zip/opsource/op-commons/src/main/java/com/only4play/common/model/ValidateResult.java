package com.only4play.common.model;

import lombok.Value;

@Value
public class ValidateResult {
  private String name;
  private String message;
}
