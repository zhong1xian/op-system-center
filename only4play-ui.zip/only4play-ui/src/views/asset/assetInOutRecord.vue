<template>
  <div class="app-container">
    <div class="block">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-input v-model="listQuery.batchNo" size="mini" placeholder="批次号" />
        </el-col>
        <el-col :span="6">
          <el-button type="success" size="mini" icon="el-icon-search" @click.native="search">查找</el-button>
          <el-button type="success" size="mini" icon="el-icon-plus" @click.native="handleAdd">添加
          </el-button>
        </el-col>
      </el-row>
      <br>
    </div>
    <el-table
      :data="list"
      style="width: 100%"
    >
      <el-table-column label="批次号">
        <template v-slot="scope">
          {{ scope.row.batchNo }}
        </template>
      </el-table-column>
      <el-table-column label="业务类型">
        <template v-slot="scope">
          {{ scope.row.inOutBizTypeTxt }}
        </template>
      </el-table-column>
      <el-table-column label="出入类型">
        <template v-slot="scope">
          {{ scope.row.inOutTypeTxt }}
        </template>
      </el-table-column>
      <el-table-column label="总数">
        <template v-slot="scope">
          {{ scope.row.totalCount }}
        </template>
      </el-table-column>
      <el-table-column label="操作人">
        <template v-slot="scope">
          {{ scope.row.operateUser }}
        </template>
      </el-table-column>
      <el-table-column label="操作时间" :width="180">
        <template v-slot="scope">
          {{ scope.row.createdAt | moment('YYYY-MM-DD HH:mm:ss') }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleUpdate(scope.row)"
          >修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      style="margin-top:15px"
      align="right"
      background
      layout="total, sizes, prev, pager, next, jumper"
      :page-size="listQuery.limit"
      :total="total"
      @current-change="fetchPage"
      @prev-click="fetchPrev"
      @next-click="fetchNext"
    />
  </div>
</template>

<script>
import {
  findByPage
} from '@/api/asset/assetInOutRecord'

export default {
  components: {},
  inheritAttrs: false,
  props: [],
  data() {
    return {
      listQuery: {
        page: 1,
        limit: 10,
        batchNo: ''
      },
      total: 0,
      list: null,
      listLoading: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.fetchData()
    },
    fetchData() {
      this.listLoading = true
      const queryData = {
        'bean': {
          'batchNo': this.listQuery.batchNo
        },
        'pageSize': this.listQuery.limit,
        'page': this.listQuery.page
      }
      findByPage(queryData).then(response => {
        this.list = response.result.content
        this.listLoading = false
        this.total = response.result.totalElements
      })
    },
    search() {
      this.fetchData()
    },
    reset() {
      this.listQuery.name = ''
      this.fetchData()
    },
    handleFilter() {
      this.listQuery.page = 1
      this.fetchData()
    },
    fetchNext() {
      this.listQuery.page = this.listQuery.page + 1
      this.fetchData()
    },
    fetchPrev() {
      this.listQuery.page = this.listQuery.page - 1
      this.fetchData()
    },
    fetchPage(page) {
      this.listQuery.page = page
      this.fetchData()
    },
    changeSize(limit) {
      this.listQuery.limit = limit
      this.fetchData()
    },
    handleUpdate() {

    },
    handleAdd() {

    }
  }
}
</script>
