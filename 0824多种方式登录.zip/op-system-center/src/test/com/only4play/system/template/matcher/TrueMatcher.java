package com.only4play.system.template.matcher;

public class TrueMatcher {

}
