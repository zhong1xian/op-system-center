import request from '@/utils/request'

export function create(params) {
  return request({
    url: '/template/templateCategory/v1/createTemplateCategory',
    method: 'post',
    data: params
  })
}

export function update(params) {
  return request({
    url: '/template/templateCategory/v1/updateTemplateCategory',
    method: 'post',
    data: params
  })
}

export function findByPage(params) {
  return request({
    url: '/template/templateCategory/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function valid(id) {
  return request({
    url: '/template/templateCategory/v1/valid/' + id,
    method: 'post'
  })
}

export function invalid(id) {
  return request({
    url: '/template/templateCategory/v1/invalid/' + id,
    method: 'post'
  })
}

export function findAllValidCategory() {
  return request({
    url: '/template/templateCategory/v1/findAllValidCategory',
    method: 'get'
  })
}

