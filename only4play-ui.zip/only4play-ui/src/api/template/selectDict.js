import request from '@/utils/request'

export function create(params) {
  return request({
    url: '/template/selectDict/v1/createSelectDict',
    method: 'post',
    data: params
  })
}

export function update(params) {
  return request({
    url: '/template/selectDict/v1/updateSelectDict',
    method: 'post',
    data: params
  })
}

export function findByPage(params) {
  return request({
    url: '/template/selectDict/v1/findByPage',
    method: 'post',
    data: params
  })
}

export function findAllByCondition(params) {
  return request({
    url: '/template/selectDict/v1/findAllByCondition',
    method: 'post',
    data: params
  })
}

export function valid(id) {
  return request({
    url: '/template/selectDict/v1/valid/' + id,
    method: 'post'
  })
}

export function invalid(id) {
  return request({
    url: '/template/selectDict/v1/invalid/' + id,
    method: 'post'
  })
}

