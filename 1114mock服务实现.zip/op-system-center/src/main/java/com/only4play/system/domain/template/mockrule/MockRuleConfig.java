package com.only4play.system.domain.template.mockrule;

import com.only4play.codegen.processor.api.GenCreateRequest;
import com.only4play.codegen.processor.api.GenQueryRequest;
import com.only4play.codegen.processor.api.GenResponse;
import com.only4play.codegen.processor.api.GenUpdateRequest;
import com.only4play.codegen.processor.controller.GenController;
import com.only4play.codegen.processor.creator.GenCreator;
import com.only4play.codegen.processor.creator.IgnoreCreator;
import com.only4play.codegen.processor.mapper.GenMapper;
import com.only4play.codegen.processor.query.GenQuery;
import com.only4play.codegen.processor.repository.GenRepository;
import com.only4play.codegen.processor.service.GenService;
import com.only4play.codegen.processor.service.GenServiceImpl;
import com.only4play.codegen.processor.updater.GenUpdater;
import com.only4play.codegen.processor.updater.IgnoreUpdater;
import com.only4play.codegen.processor.vo.GenVo;
import com.only4play.common.annotation.FieldDesc;
import com.only4play.common.constants.ValidStatus;
import com.only4play.jpa.converter.ValidStatusConverter;
import com.only4play.jpa.support.BaseJpaAggregate;
import lombok.Data;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Table;

@GenVo(pkgName = "com.only4play.system.domain.template.mockrule.vo")
@GenCreator(pkgName = "com.only4play.system.domain.template.mockrule.creator")
@GenUpdater(pkgName = "com.only4play.system.domain.template.mockrule.updater")
@GenRepository(pkgName = "com.only4play.system.domain.template.mockrule.repository")
@GenService(pkgName = "com.only4play.system.domain.template.mockrule.service")
@GenServiceImpl(pkgName = "com.only4play.system.domain.template.mockrule.service")
@GenQuery(pkgName = "com.only4play.system.domain.template.mockrule.query")
@GenMapper(pkgName = "com.only4play.system.domain.template.mockrule.mapper")
@GenController(pkgName = "com.only4play.system.controller")
@GenCreateRequest(pkgName = "com.only4play.system.domain.template.mockrule.request")
@GenUpdateRequest(pkgName = "com.only4play.system.domain.template.mockrule.request")
@GenQueryRequest(pkgName = "com.only4play.system.domain.template.mockrule.request")
@GenResponse(pkgName = "com.only4play.system.domain.template.mockrule.response")
@Entity
@Table(name = "mock_rule_config")
@Data
public class MockRuleConfig extends BaseJpaAggregate {

    @FieldDesc(name = "描述信息")
    private String descInfo;

    @FieldDesc(name = "规则名称")
    private String name;

    @FieldDesc(name = "规则编码")
    private String code;

    @FieldDesc(name = "生成规则JSON参数值")
    private String params;

    private Integer sortNum;

    @Convert(converter = ValidStatusConverter.class)
    @IgnoreUpdater
    @IgnoreCreator
    private ValidStatus validStatus;

    public void init() {
        setValidStatus(ValidStatus.VALID);
    }

    public void valid() {
        setValidStatus(ValidStatus.VALID);
    }

    public void invalid() {
        setValidStatus(ValidStatus.INVALID);
    }
}
