package com.only4play.system.template.extension;

public interface IStudentService {

  String getName();

  String getGrade();
}
