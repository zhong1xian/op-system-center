@QueryEntities(value = {BaseJpaAggregate.class})
package com.only4play.system;

import com.only4play.jpa.support.BaseJpaAggregate;
import com.querydsl.core.annotations.QueryEntities;

