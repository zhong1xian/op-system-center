package com.design.elegant.charge;

import lombok.Data;

@Data
public class ChargeModel {

  private User user;


}
